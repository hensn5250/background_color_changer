# background_color_changer
The page's background color changes when the 'click' button is pressed.
